def cores(num):
    cor = ['\033[m', #0 - Sem cores
        '\033[31m',  #1 - Vermelho
        '\033[35m',  #2 - Magenta
        '\033[32m'   #3 - Verde
        '\033[34m']  #4 - Azul
    return cor[num]


def leiaInt(num):
    while True:
        try:
            n1 = int(input(num))
        except KeyboardInterrupt:
            n1 = 0
            print('\nO usuário preferiu não digitar esse número.')
            break
        except:
            print('\033[31mErro! Digite um número inteiro válido.\033[m')
            continue
        else:
            return n1


def linha(tam=40):
    print('~' * 40)


def cab(msg):
    linha()
    print(f'{msg}'.center(40))
    linha()


def menu(lista):
    cab('MENU PRINCIPAL')
    for p,i in enumerate(lista):
        print(f'{cores(1)}{p+1}{cores(0)} - {cores(2)}{i}{cores(0)}')
    linha()
    opc = leiaInt('Sua opção: ')
    return opc

