from desafio115.lib.inteface import *

def existeArquivo(arq):
    try:
        a = open(arq, 'rt')
        a.close()
    except FileNotFoundError:
        return False
    else:
        return True


def criarArquivo(arq):
    try:
        a = open(arq, 'wt+')
        a.close()
    except:
        print('Houve um erro na criação do arquivo.')
    else:
        print(f'Arquivo {arq} criado com sucesso.')


def lerArquivo(arq):
    try:
        a = open(arq, 'rt')
    except:
        print('Erro ao abrir arquivo.')
    else:
        cab('PESSOAS CADASTRADAS')
        for linha in a:
            dado = linha.split(';')
            dado[1] = dado[1].replace('\n','')
            print(f'{dado[0]:<30}{dado[1]:>3} anos')


def escreverArquivo(arq, nome, idade):
    try:
        a = open(arq, 'at')
    except:
        print('Erro ao tentar abrir no arquivo.')
    else:
        try:
            a.write(f'{nome};{idade}\n')
        except:
            print('Erro ao tentar escrever no arquivo.')
        else:
            print(f'Novo registro de {nome} adicionado.')
    finally:
        a.close()