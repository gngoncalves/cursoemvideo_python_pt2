from desafio115.lib.inteface import *
from desafio115.lib.arquivo import *

arquivo = 'dados.txt'

if not existeArquivo(arquivo):
    criarArquivo(arquivo)

while True:
    resp = menu(['Ver pessoas cadastradas', 'Cadastrar nova pessoa', 'Sair do sistema'])
    if resp == 1:
        lerArquivo(arquivo)
    elif resp == 2:
        cab('NOVO CADASTRO')
        nome = str(input('Nome: '))
        idade = int(input('Idade: '))
        escreverArquivo(arquivo, nome, idade)
    elif resp == 3:
        cab('Saindo do Sistema... Até!')
        break
    else:
        print('Erro! Digite uma opção válida!')