def moeda(n):
    return f'R${n:.2f}'