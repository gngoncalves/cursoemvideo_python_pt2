from desafio108 import calc, moeda

n = float(input('Digite o preço: R$'))
print(f'A metade de {moeda.moeda(n)} é {moeda.moeda(calc.metade(n))}.')
print(f'O dobro de {moeda.moeda(n)} é {moeda.moeda(calc.dobro(n))}.')
a = float(input('Digite o percentual de aumento: '))
print(f'Aumentando {a}% de {moeda.moeda(n)}, temos {moeda.moeda(calc.aumentar(n, a))}.')
d = float(input('Digite o percentual de redução: '))
print(f'Reduzindo {d}% de {moeda.moeda(n)}, temos {moeda.moeda(calc.diminuir(n, d))}.')
