import calc

n = float(input('Digite o preço: R$'))
print(f'A metade de {n} é {calc.metade(n)}.')
print(f'O dobro de {n} é {calc.dobro(n)}.')
a = float(input('Digite o percentual de aumento: '))
print(f'Aumentando {a}% de {n}, temos {calc.aumentar(n, a)}.')
d = float(input('Digite o percentual de redução: '))
print(f'Reduzindo {d}% de {n}, temos {calc.diminuir(n, d)}.')
