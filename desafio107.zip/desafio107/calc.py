
def dobro(n1, f1=False):
    n1 *= 2
    return n1


def metade(n2):
    n2 /= 2
    return n2


def aumentar(n3, aum):
    n3 = n3 * (100 + aum)/100
    return n3


def diminuir(n4, dim):
    n4 = n4 * (100 - dim)/100
    return n4


