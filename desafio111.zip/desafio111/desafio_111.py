from utilidadesCeV import moeda

n = float(input('Digite o preço: R$'))
a = int(input('Digite o percentual para cálculo de aumento: '))
d = int(input('Digite o percentual para cálculo de redução: '))
f = str(input('Deseja o seu resultado com formatação? [S/N] ')).strip()[0]
if f in 'Ss':
    f = True
elif f in 'Nn':
    f= False
moeda.resumo(n, a, d, f)