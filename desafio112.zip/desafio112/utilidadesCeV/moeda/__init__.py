def dobro(n=0, f=False):
    n *= 2
    if f:
        return moeda(n)
    else:
        return n


def metade(n=0, f=False):
    n /= 2
    if f:
        return moeda(n)
    else:
        return n


def aumentar(n=0, aum=0, f=False):
    n = n * (100 + aum)/100
    if f:
        return moeda(n)
    else:
        return n


def diminuir(n=0, dim=0, f=False):
    n = n * (100 - dim)/100
    if f:
        return moeda(n)
    else:
        return n


def moeda(n=0, real='R$'):
    return f'{real}{n:.2f}'.replace('.',',')


def resumo(n=0, a=0, d=0, f=True):
    print('-' * 30)
    print(f'{"RESUMO DO VALOR"}'.center(30))
    print('-' * 30)
    print(f'Preço analisado: \t{moeda(n)}')
    print(f'Dobro do Preço: \t{dobro(n, f)}')
    print(f'Metade do Preço: \t{metade(n,f)}')
    print(f'{a}% de aumento: \t{aumentar(n, a, f)}')
    print(f'{d}% de redução: \t{diminuir(n, d, f)}')
    print('-' * 30)
