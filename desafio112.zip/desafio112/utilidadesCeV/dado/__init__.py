def leiaDinheiro(msg):
    while True:
        n = str(input(msg)).strip().replace(',', '.')
        n1 = n.replace('.','')
        t1 = n.count(',')
        t2 = n.count('.')
        if n1.isnumeric() and t1 == 0 and t2 == 1 or t1 == 1 and t2 == 0:
            n = float(n)
            return n
        elif n1.isnumeric() and t1 == 0 and t2 == 0:
            n = float(n)
            return n
        else:
            print(f'\033[31mERRO: "{n}" possui um formato inválido! Tente novamente!\033[m')

