def dobro(n1=0, f1=False):
    n1 *= 2
    if f1:
        return moeda(n1)
    else:
        return n1


def metade(n2=0, f2=False):
    n2 /= 2
    if f2:
        return moeda(n2)
    else:
        return n2


def aumentar(n3=0, aum=0, f3=False):
    n3 = n3 * (100 + aum)/100
    if f3:
        return moeda(n3)
    else:
        return n3


def diminuir(n4=0, dim=0, f4=False):
    n4 = n4 * (100 - dim)/100
    if f4:
        return moeda(n4)
    else:
        return n4


def moeda(n5=0, real='R$'):
    return f'{real}{n5:.2f}'.replace('.',',')

