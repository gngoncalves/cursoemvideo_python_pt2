from desafio109 import calc

n = float(input('Digite o preço: R$'))
f = str(input('Deseja o seu resultado com formatação? [S/N] ')).strip()[0]
if f in 'Ss':
    f = True
elif f in 'Nn':
    f= False
print(f'A metade de {calc.moeda(n)} é {(calc.metade(n, f))}.')
print(f'O dobro de {calc.moeda(n)} é {(calc.dobro(n, f))}.')
a = float(input('Digite o percentual de aumento: '))
print(f'Aumentando {a}% de {calc.moeda(n)}, temos {(calc.aumentar(n, a, f))}.')
d = float(input('Digite o percentual de redução: '))
print(f'Reduzindo {d}% de {calc.moeda(n)}, temos {(calc.diminuir(n, d, f))}.')
